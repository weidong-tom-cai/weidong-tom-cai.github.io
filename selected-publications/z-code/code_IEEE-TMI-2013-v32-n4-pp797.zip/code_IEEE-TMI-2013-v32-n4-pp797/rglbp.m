%rglbp implements the RGLBP feature vector described in our paper:
% Yang Song, Weidong Cai, Yun Zhou, Dagan Feng, 
% “Feature-based Image Patch Approximation for Lung Tissue Classification”, 
% IEEE Transactions on Medical Imaging, Vol.32, No.4, pp797-808, 2013.
%
%The LBP package is downloaded from http://www.cse.oulu.fi/CMV/Downloads/LBPMatlab.
%
%Input:
%img -- the image matrix data
%r,c -- the centroid (row and column index) of the image patch, for which the feature vector
%       is to be computed
%bs -- the size of the image patch is bs*2+1
%Output:
%fv -- the feature vector

function fv = rglbp( img, r, c, bs )

img = double(img);
img2 = img/max(img(:))*255;
imgset = filter_gab(img2);
            
mapping=getmapping(8,'ri');
vx = zeros(size(imgset,2),36);
for k=1:size(imgset,2)
	blk = imgset(k).img(r-bs:r+bs,c-bs:c+bs);
	blk = blk/max(blk(:))*250;
	blk = uint8(blk);
	vx(k,:) = lbp(blk,1,8,mapping,'h'); 
end        

fv = vx(:);

end

function out = filter_gab( in )
%This function outputs M Gabor filtered images with M as the number of scales.
%N is the number of orientations.

%The following parameters may be redefined here
M = 3;
N = 4;
Lx = 6;
Ly = 6;

Gab = gabor(M,N,Lx,Ly);
for m=1:M
	for n=1:N
		filx = conv2(in, real(Gab(m,n).filter), 'same');
		filx = filx.*(filx>=0);
		if n==1
			filimg(m).img = filx;
		else
			filimg(m).img = filimg(m).img+filx;
		end        
	end    
end

out = filimg;

end










