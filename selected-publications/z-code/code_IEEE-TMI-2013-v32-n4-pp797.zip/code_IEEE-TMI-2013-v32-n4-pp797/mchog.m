%rglbp implements the RGLBP feature vector described in our paper:
% Yang Song, Weidong Cai, Yun Zhou, Dagan Feng, 
% “Feature-based Image Patch Approximation for Lung Tissue Classification”, 
% IEEE Transactions on Medical Imaging, Vol.32, No.4, pp797-808, 2013.
%
%This function is developed based on http://au.mathworks.com/matlabcentral/fileexchange/28689-hog-descriptor-for-matlab/content/HOG.m
%
%Input:
%img -- the image matrix data
%r,c -- the centroid (row and column index) of the image patch, for which the feature vector
%       is to be computed
%bs -- the size of the image patch is bs*2+1
%Output:
%fv -- the feature vector

function fv = mchog(img, r, c, bs)

img = double(img);
img2 = img/max(img(:))*255;
Im = img2(r-bs:r+bs,c-bs:c+bs);
Im = uint8(Im);

%The following parameters may be redefined here
nwin_x=2;
nwin_y=2;
B=9;

[L,C]=size(Im); % L num of lines ; C num of columns
fv=zeros(nwin_x*nwin_y*B,1); % column vector with zeros
m=sqrt(L/2);
if C==1 % if num of columns==1
    Im=im_recover(Im,m,2*m);%verify the size of image, e.g. 25x50
    L=2*m;
    C=m;
end
Im=double(Im);
step_x=floor(C/(nwin_x+1));
step_y=floor(L/(nwin_y+1));
cont=0;

grad_xr = zeros(L,C);
grad_yu = zeros(L,C);
cenr = ceil(L/2);
cenc = ceil(C/2);
Im = padarray(Im, [1 1], 'replicate');
for r=2:L+1
    for c=2:C+1
        if c==cenc
            v=-100;
        else
            v = atand((cenr-r)/(c-cenc));
        end
        if abs(v)<=22.5 && c>cenc
            grad_xr(r-1,c-1) = Im(r+1,c)-Im(r-1,c);
            grad_yu(r-1,c-1) = Im(r,c+1)-Im(r,c-1);
        elseif v>22.5 && v<=67.5 && r<cenr
            grad_xr(r-1,c-1) = Im(r+1,c+1)-Im(r-1,c-1);
            grad_yu(r-1,c-1) = Im(r-1,c+1)-Im(r+1,c-1);
        elseif abs(v)>67.5 && r<cenr
            grad_xr(r-1,c-1) = Im(r,c+1)-Im(r,c-1);
            grad_yu(r-1,c-1) = Im(r-1,c)-Im(r+1,c);
        elseif v>-67.5 && v<=-22.5 && r<cenr
            grad_xr(r-1,c-1) = Im(r-1,c+1)-Im(r+1,c-1);
            grad_yu(r-1,c-1) = Im(r-1,c-1)-Im(r+1,c+1);
        elseif abs(v)<=22.5 && c<cenc
            grad_xr(r-1,c-1) = Im(r-1,c)-Im(r+1,c);
            grad_yu(r-1,c-1) = Im(r,c-1)-Im(r,c+1);
        elseif v>22.5 && v<=67.5 && r>cenr
            grad_xr(r-1,c-1) = Im(r-1,c-1)-Im(r+1,c+1);
            grad_yu(r-1,c-1) = Im(r+1,c-1)-Im(r-1,c+1);
        elseif abs(v)>67.5 && r>cenr
            grad_xr(r-1,c-1) = Im(r,c-1)-Im(r,c+1);
            grad_yu(r-1,c-1) = Im(r+1,c)-Im(r-1,c);
        elseif v>-67.5 && v<=-22.5 && r>cenr
            grad_xr(r-1,c-1) = Im(r+1,c-1)-Im(r-1,c+1);
            grad_yu(r-1,c-1) = Im(r+1,c+1)-Im(r-1,c-1);
        end
    end
end
angles=atan2(grad_yu,grad_xr);
magnit=((grad_yu.^2)+(grad_xr.^2)).^.5;
%imtool(magnit,  []);

for n=0:nwin_y-1
    for m=0:nwin_x-1
        cont=cont+1;
        angles2=angles(n*step_y+1:(n+2)*step_y,m*step_x+1:(m+2)*step_x); 
        magnit2=magnit(n*step_y+1:(n+2)*step_y,m*step_x+1:(m+2)*step_x);
        v_angles=angles2(:);    
        v_magnit=magnit2(:);
        K=max(size(v_angles));
        %assembling the histogram with 9 bins (range of 20 degrees per bin)
        bin=0;
        H2=zeros(B,1);
        for ang_lim=-pi+2*pi/B:2*pi/B:pi
            bin=bin+1;
            for k=1:K
                if v_angles(k)<ang_lim
                    v_angles(k)=100;
                    H2(bin)=H2(bin)+v_magnit(k);
                end
            end
        end
                
        H2=H2/(norm(H2)+0.01);        
        fv((cont-1)*B+1:cont*B,1)=H2;
    end
end

end


