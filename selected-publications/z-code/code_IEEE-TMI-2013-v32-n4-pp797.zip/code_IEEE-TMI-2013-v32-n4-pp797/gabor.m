%%%%%%%VERSION 2
%%ANOTHER DESCRIBTION OF GABOR FILTER

%The Gabor filter is basically a Gaussian (with variances sx and sy along x and y-axes respectively)
%modulated by a complex sinusoid (with centre frequencies U and V along x and y-axes respectively) 
%described by the following equation
%%
%               1                -1     x  ^    y  ^
%%% G(x,y) = ---------- * exp ([----{(----) 2+(----) 2}+2*pi*i*W*x])
%            2*pi*sx*sy           2    sx       sy
%%% G'(x,y) = a^(-m)*G(x',y')
%%% x' = a^(-m)*(x*cos(theta)+y*sin(theta));
%%% y' = a^(-m)*(y*cos(theta)-x*sin(theta));
%%% theta = n*pi/N; n = 0,1,...N-1
%%% m = 0,1,...M-1
%
% Gout = Gabor(imgseg.suv,6,4,6,6);

%%
function out = gabor(M,N,Lx,Ly)

Uh = 2;
Ul = 0.1;
a = (Uh/Ul)^(1/(M-1));

G  = zeros(Lx+Lx+1, Ly+Ly+1);

for m = 0:M-1
    w = (a^m)*Ul;
    sx = (a+1)*sqrt(2*log(2))/(2*pi*(a^m)*(a-1)*Ul);
    sy = 1/(2*pi*tan(pi/(2*N))*sqrt(Uh^2/(2*log(2))-(1/(2*pi*sx))^2));
    factor = (a^(-m)) * (1/(2*pi*sx*sy));
    for n = 0:N-1
        theta = n*pi/N;        
        for x = -fix(Lx):fix(Lx)
            for y = -fix(Ly):fix(Ly)
                xPrime = (a^(-m)) * (x*cos(theta) + y*sin(theta));
                yPrime = (a^(-m)) * (y*cos(theta) - x*sin(theta));                
                G(fix(Lx)+x+1,fix(Ly)+y+1) = ...
                factor*exp(-.5*((xPrime/sx)^2+(yPrime/sy)^2)+2*pi*1i*w*xPrime);
            end
        end        
        out(m+1,n+1).filter = G;
    end
end



end

