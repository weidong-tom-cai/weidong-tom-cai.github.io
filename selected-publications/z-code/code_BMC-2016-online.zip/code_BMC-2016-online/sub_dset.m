function out = sub_dset( dset, csetall )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

for i=1:size(csetall,2)
    ids = csetall(i).idx;
    if numel(ids)==0
        continue;
    end
    numk = max(ids);
    for k=1:numk
        dict = dset(i).dict;
        cnt = sum(ids==k); 
        if cnt==0
            subdsets(i).set(k).dict = [];
            continue;
        end
        dictx = zeros(cnt,size(dict,2)-1);
        cnt = 0;
        for j=1:size(dict,1)
            fv = dict(j,:);
            if ids(j)==k
                cnt = cnt+1;
                dictx(cnt,:) = fv(2:numel(fv));
            end
        end
        subdsets(i).set(k).dict = dictx;
    end
end

out = subdsets;

end

