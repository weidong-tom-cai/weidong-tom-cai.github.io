function out = apply_filter( dset, filset, fdim, len )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

for a=2:numel(fdim)
    for i=1:len(a)/fdim(a)
        x = len./fdim;
        dset = conv_fil(dset,sum(len(1:a-1))+(i-1)*fdim(a)+1,fdim(a),filset(sum(x(1:a-1))+i).mask);
    end
end

out = dset;

end

function out = conv_fil(dset, sp, len, mask)

for i=1:size(dset,2)
    dict = dset(i).dict;   
    if numel(dict)==0
        continue;
    end
    fm = dict(:,sp+1:sp+len);    
    tnorm = 0;
    for k=1:size(fm,1)
        tnorm = tnorm+norm(fm(k,:));
    end
    anorm = tnorm/size(fm,1);
    tnorm = 0;
    for k=1:size(fm,1)
        x = fm(k,:);
        x = conv(x,mask,'same');
        fm(k,:) = x;
        tnorm = tnorm+norm(x);
    end
    anorm2 = tnorm/size(fm,1);
    if anorm~=0 && anorm2~=0
        for k=1:size(fm,1)
            x = fm(k,:);
            x = x/anorm2*anorm;
            fm(k,:) = x;
        end
    end
    dict(:,sp+1:sp+len) = fm;
    dset(i).dict = dict;
end

out = dset;

end

