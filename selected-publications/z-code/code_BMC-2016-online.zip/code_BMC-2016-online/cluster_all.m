function out = cluster_all( dset )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

numc = size(dset,2);
numv = 20;

cnt = 0;
for k=1:size(dset,2)
    cnt = cnt+size(dset(k).dict,1);
    len = size(dset(k).dict,2)-1;
end
data = zeros(cnt,len);

cnt = 0;
for k=1:size(dset,2)
    dict = dset(k).dict;
    data(cnt+1:cnt+size(dict,1),:) = dict(:,2:len+1);
    cnt = cnt+size(dict,1);
end

L=LLC_coding_appr(2,data,data,numv,1e-4);
for i = 1 : size(L,1)
    L(i,:) = L(i,:)/max(abs(L(i,:)));    
end
Z = ( abs(L) + abs(L') )/2;
idx = clu_ncut(Z,numc);

cnt = 0;
for k=1:size(dset,2)
    dict = dset(k).dict;
    ids = idx(cnt+1:cnt+size(dict,1));
    id2 = zeros(1,max(ids));
    cur = 0;
    for i=1:max(ids)
        tmp = (ids==i);
        if sum(tmp)>0
            cur = cur+1;
            id2(i) = cur;
        end
    end
    for i=1:numel(ids)
        ids(i) = id2(ids(i));
    end
    csetall(k).idx = ids;
end

out = csetall;            

end

