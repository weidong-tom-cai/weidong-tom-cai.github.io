function out = test_filter( dsetx, dsety )
%Input:
%dsetx -- a data structure containing the feature descriptors of the training data.
%dsety -- a data structure containing the feature descriptors of the testing data.
%        Assuming the data has two classes, dsetx and dsety should be structured as follows.
%        dset(1).dict -- is an N by (1+H) matrix, in which each row corresponds to one data instance,
%                        and H is the length of the feature vector. 
%                        For each row, the first element contains
%                        the subject ID and the rest elements contain the feature vector.
%        dset(2).dict -- has the same format as dset(1).dict.
%Note: each data instance in dset(1).dict contains five types of feature descriptors:
%		LPB, HOG, GIST, IFV, and CENTRIST;
%		Refer to the "bs" parameter setting in the following.
%Output:
%out -- classification accuracy

% NOTE: The parameter "bs" needs to be set manually
% This parameter corresponds to the variable "D" defined in the paper
% The first element in bs should be fixed as 0
% Elements 2 to 5 contain the "D" value for 
% the LBP, HOG, GIST, IFV, and CENTRIST descriptors, respectively.
bs = [0,3,3,3,5];

%fdim and len are fixed and the elements correspond to the
%LBP, HOG, GIST, IFV, and CENTRIST descriptors
%They can be changed if some of the descriptors should be omitted. 
fdim = [1,58,31,32,64,64];
len = [0,928,496,512,64*64*2,256];	

%The main functions in SDT
csetall = cluster_all(dsetx);
subdsets = sub_dset(dsetx,csetall);    
filset = gen_filter2(subdsets,bs,fdim,len);
dsetxf = apply_filter(dsetx,filset,fdim,len);
dsetyf = apply_filter(dsety,filset,fdim,len);
svm = learn_svms(dsetxf);
[lx,accx] = label_svms2(dsetyf,svm);

out = accx;

end

