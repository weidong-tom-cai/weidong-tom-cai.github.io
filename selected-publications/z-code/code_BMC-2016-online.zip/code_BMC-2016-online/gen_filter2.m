function out = gen_filter2( subdsets, bs, fdim, len )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

for a=2:numel(fdim)
    for i=1:len(a)/fdim(a)
        x = len./fdim;
        [filset(sum(x(1:a-1))+i).mask,filset(sum(x(1:a-1))+i).obj] = comp_fil(subdsets,bs(a),sum(len(1:a-1))+(i-1)*fdim(a)+1,fdim(a));
    end
end

out = filset;
    
end

function [out,obj] = comp_fil(subdsets, bs, sp, len)

num = 0;
for i=1:size(subdsets,2)
    set = subdsets(i).set;
    for j=1:size(set,2)        
        dict = set(j).dict;
        if size(dict,1)==0
            continue;
        end
        num = num+1;
    end
end
lb = zeros(1,num);
dmx = zeros(num,bs);
nt = zeros(1,num);

cnt = 0;
for i=1:size(subdsets,2)
    set = subdsets(i).set;
    for j=1:size(set,2)        
        dict = set(j).dict;
        if size(dict,1)==0
            continue;
        end
        cnt = cnt+1;
        lb(cnt) = i;
        fm = dict(:,sp:sp+len-1);    
        for k=1:bs:len-bs+1
            pdv = fm(:,k:k+bs-1);
            pdv = fliplr(pdv);
            dmx(cnt,:) = dmx(cnt,:)+sum(pdv);
            nt(cnt) = nt(cnt)+size(fm,1);
        end
    end
end

dm = sum(dmx)/sum(nt);
for i=1:size(dmx,1)
    dmx(i,:) = dmx(i,:)/nt(i);
end

sw = zeros(bs,bs);
cnt = 0;
for i=1:size(subdsets,2)
    set = subdsets(i).set;
    for j=1:size(set,2)        
        dict = set(j).dict;
        if size(dict,1)==0
            continue;
        end
        cnt = cnt+1;
        fm = dict(:,sp:sp+len-1);    
        for k=1:bs:len-bs+1
            pdv = fm(:,k:k+bs-1);
            pdv = fliplr(pdv);
            for a=1:size(pdv,1)
                dI = pdv(a,:)-dmx(cnt,:);
                v = dI'*dI;
                sw = sw+v;
            end
        end
    end
end

sw2 = zeros(bs,bs);
sb = zeros(bs,bs);
for i=1:size(dmx,1)
    for j=1:size(dmx,1)
        if i==j 
            continue;
        elseif lb(i)==lb(j)
            dI = dmx(i,:)-dmx(j,:);
            v = dI'*dI;
            x = (lb==lb(i));
            sw2 = sw2+v*nt(i)/(sum(x)-1);
        else
            dI = dmx(i,:)-dmx(j,:);
            v = dI'*dI;
            x = (lb~=lb(i));
            %w = nt(j)/sum(nt.*x);
            sb = sb+v*nt(i)/sum(x);
        end
    end
end

[V,D] = eig(sb,sw2);
fil = V(:,end);

mask = fil';

out = mask;
obj.sb = fil'*sb*fil;
obj.sw = fil'*sw2*fil;

fil = zeros(bs,1);
fil(ceil(bs/2)) = 1;
obj.sb0 = fil'*sb*fil;
obj.sw0 = fil'*sw2*fil;
obj.D = D;

end




