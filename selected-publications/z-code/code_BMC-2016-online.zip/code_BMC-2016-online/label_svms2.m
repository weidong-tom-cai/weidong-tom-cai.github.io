function [out, acc] = label_svms2( dset, svms )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

cnt = 0;
for k=1:size(dset,2)
    dict = dset(k).dict;
    cnt = cnt+size(dict,1);
end
svmmat = zeros(size(dset,2),cnt);
cnt = 0;
acc = 0;
for k=1:size(dset,2)
    k
    dict = dset(k).dict;
    lm = zeros(size(dict,1),1);
    for i=1:size(dict,1)
        fv = dict(i,:);
        cnt = cnt+1;
        fv = fv(2:numel(fv));
        for a=1:size(dset,2)
            v = fv*svms(a).svmset.w-svms(a).svmset.b;
            p = 1/(1+exp(svms(a).svmset.pa*v+svms(a).svmset.pb));
            svmmat(a,cnt) = p;
        end
        [x,lb] = max(svmmat(:,cnt));
        if lb==k
            acc = acc+1;
        end
        lm(i) = lb;
    end
    lmset(k).lm = lm;
end
acc = acc/cnt;

out = lmset;

end

