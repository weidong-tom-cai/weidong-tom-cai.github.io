function out = learn_svms( dset )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

for k=1:size(dset,2)
    dict = dset(k).dict;
    dictx = dict(:,2:size(dict,2));
    subdsets(k).set(1).dict = dictx;
end
svms = train_fuse(subdsets);

out = svms;

end

function out = train_fuse( subdsets )

for k=1:size(subdsets,2)
    set = subdsets(k).set;
    for n=1:size(set,2)
        [svm,w] = check_cluster(subdsets,k,n);  
        if numel(w)==1
            allsvm(k).svmset(n).w = 0;
        else
            b = svm.rho;
            pa = svm.ProbA;
            pb = svm.ProbB;
            allsvm(k).svmset(n).w = w;
            allsvm(k).svmset(n).b = b;
            allsvm(k).svmset(n).pa = pa;
            allsvm(k).svmset(n).pb = pb;
        end
        %allsvm(k).svmset(n).svm = svm;
        [k,n]
    end
end

out = allsvm;

end

function [svm,w] = check_cluster(subdsets, ck, cn)

dict = subdsets(ck).set(cn).dict;
tr_num = size(dict,1);
if tr_num==0
    svm = 0;
    w = 0;
    return;
end
len = size(dict,2);

for k=1:size(subdsets,2)
    if k==ck
        continue;
    end
    set = subdsets(k).set;
    for n=1:size(set,2)
        dictx = set(n).dict;
        tr_num = tr_num+size(dictx,1);
    end
end

tr_data = zeros(tr_num,len);
tr_label = zeros(tr_num,1);
tr_data(1:size(dict,1),:) = dict;
tr_label(1:size(dict,1)) = 1;
tr_num = size(dict,1);

for k=1:size(subdsets,2)
    if k==ck
        continue;
    end
    set = subdsets(k).set;
    for n=1:size(set,2)
        dictx = set(n).dict;
        if size(dictx,1)==0
            continue;
        end
        tr_data(tr_num+1:tr_num+size(dictx,1),:) = dictx;
        tr_label(tr_num+1:tr_num+size(dictx,1)) = -1;
        tr_num = tr_num+size(dictx,1);
    end
end

K = tr_data*tr_data';
K = [(1:size(K,1))', K+eye(size(K,1))*realmin];
svm = svmtrain(tr_label, K, '-t 4 -c 3 -b 1'); 
[l,r,p] = svmpredict(tr_label, K, svm, '-b 1');
r

w = zeros(1,len);
svs = svm.SVs;
[v,loc] = ismember(svs,[1:size(tr_data,1)]);
coef = svm.sv_coef;
for i=1:numel(coef)
    x = tr_data(loc(i),:)*coef(i);
    w = w+x;
end
w = w';

end







