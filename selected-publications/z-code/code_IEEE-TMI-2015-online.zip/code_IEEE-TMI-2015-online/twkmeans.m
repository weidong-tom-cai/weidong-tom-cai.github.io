%twkmeans is invoked by gen_cluster for "reference sub-categorization" as described in our paper:
% Yang Song, Weidong Cai, Heng Huang, Yun Zhou, Dagan Feng, Yue Wang, Michael Fulham, Mei Chen, 
% “Large Margin Local Estimate with Applications to Medical Image Classification”, 
% IEEE Transactions on Medical Imaging, online, 2015.

function [U,W,V,Z] = twkmeans( dm, k, vp, C1, C2, Z )

delta = 0.00001;
num = size(dm,1);
dim = size(dm,2);
eta = C1;
lamda = C2;

T = max(vp);
W = ones(1,T)/T;
V = zeros(1,dim);
Wx = zeros(1,dim);
for t=1:T
    tmp = (vp==t);
    x = 1/sum(tmp);
    V = V + x*tmp;
    Wx = Wx + W(t)*tmp;
end
U = zeros(1,num);

r = 0;
P0 = 0;
while 1
    %update U
    Ux = zeros(num,k);
    for i=1:num        
        Dl = zeros(1,k);
        for l=1:k
            Dl(l) = sum(Wx.*V.*((dm(i,:)-Z(l,:)).^2));
        end
        [tmp,id] = min(Dl);
        U(i) = id;
        Ux(i,id) = 1;
    end
    %update Z
    for l=1:k
        Ul = (U==l);
        nl = sum(Ul);
        for j=1:dim
            tmp = sum(Ul.*dm(:,j)');
            Z(l,j) = tmp/nl;
        end
    end
    %update V
    E = zeros(1,dim);
    for j=1:dim      
        t = vp(j);
        Zj = Ux*Z(:,j);
        tmp = (dm(:,j)-Zj).^2;
        E(j) = sum(W(t)*tmp);
        E(j) = exp(-E(j)/eta);
    end
    df = zeros(1,T);
    for t=1:T
        tmp = (vp==t);
        df(t) = sum(tmp.*E);
    end
    for j=1:dim
        t = vp(j);
        V(j) = E(j)/df(t);
    end
    %update W
    D = zeros(1,T);
    for t=1:T
        for j=1:dim
            if vp(j)~=t
                continue;
            end
            Zj = Ux*Z(:,j);
            tmp = sum(V(j)*((dm(:,j)-Zj).^2));
            D(t) = D(t)+tmp;
        end
        D(t) = exp(-D(t)/lamda);
    end
    df = sum(D);
    Wx = zeros(1,dim);
    for t=1:T
        W(t) = D(t)/df;
        tmp = (vp==t);
        Wx = Wx + W(t)*tmp;
    end
    %compute P
    P = 0;
    for j=1:dim
        Zj = Ux*Z(:,j);
        tmp = sum(V(j)*((dm(:,j)-Zj).^2));
        P = P+tmp*Wx(j);
    end
    for j=1:dim
        P = P + eta*V(j)*log(V(j));
    end
    for t=1:T
        P = P + lamda*W(t)*log(W(t));
    end
    r = r+1;   
    if r==100 || abs(P-P0)<=delta
        %[r, P]
        %W
        break;
    end
    P0 = P;
end
            
    
end


