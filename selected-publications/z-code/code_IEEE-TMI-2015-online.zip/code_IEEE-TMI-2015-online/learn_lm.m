%learn_lm learns the transformation matrices for "large margin aggregation" as described in our paper:
% Yang Song, Weidong Cai, Heng Huang, Yun Zhou, Dagan Feng, Yue Wang, Michael Fulham, Mei Chen, 
% “Large Margin Local Estimate with Applications to Medical Image Classification”, 
% IEEE Transactions on Medical Imaging, online, 2015.
%
%Input:
%dset -- a data structure containing the feature descriptors of references.
%        Assuming the data has two classes, dset should be structured as follows.
%        dset(1).dict -- is an N by (1+H) matrix, in which each row corresponds to one data instance,
%                        and H is the length of the feature vector. 
%                        For each row, the first element contains
%                        the subject ID and the rest elements contain the feature vector.
%        dset(2).dict -- has the same format as dset(1).dict.
%cint -- the assignment of clusters.
%        Assuming the data has two classes, cint is structured as follows.
%        cint(1).ids -- is a 1 by N vector, with each element containing the cluster ID of that data instance.
%        cint(2).ids -- has the same format as cint(1).ids.
%tr_set -- a vector containing the subject IDs of the training set.
%Output:
%Lm -- a data structure containing the learned transformation matrices.
%      Assuming the data has two classes, Lm should be structured as follows.
%      Lm(1).L -- is an H by H matrix containing the transformation matrix learned for class 1.
%      Lm(2).L -- is an H by H matrix containing the transformation matrix learned for class 2.

function Lm = learn_lm( dset, cint, tr_set )

for k=1:size(dset,2)
    cnt = 0;
    recm = [];
    dict = dset(k).dict;
    for i=1:size(dict,1)
        v = dict(i,1);
		if any(tr_set==v)
			cnt = cnt+1;
			tr_ids(cnt) = i;
			recm(cnt).rec = label_cluster(dict(i,2:size(dict,2)),v,dset,cint);
		end 
    end
    numel(tr_ids)
    L = train_lmnn( dset, tr_ids, recm, k );
    Lm(k).L = L;
end

end

function L = train_lmnn( dset, tr_ids, recm, tl )
%Parameter:
%nknn -- the number of top local estimates used (i.e. M in the paper).
nknn = 3; 

tr_data = [];
tr_label = [];
cnt = 0;
tr_set = [];
dict = dset(tl).dict;
for id=1:numel(tr_ids)
    i = tr_ids(id);
    fv = dict(i,2:size(dict,2));
    cnt = cnt+1;
    tr_data(:,cnt) = fv';
    tr_label(1,cnt) = tl;
    tr_set = [tr_set,cnt];
    rec = recm(id).rec;
    for a=1:size(rec,2) 
        if numel(rec(a).diff)==1 && rec(a).diff==0
            continue;
        end
        for b=1:size(rec(a).diff,2)
            if rec(a).diff(b)==0
                continue;
            end
            cnt = cnt+1;
            tr_data(:,cnt) = rec(a).vm(b,:)';
            tr_label(1,cnt) = a;
        end
    end
end
size(tr_data)

[L,Det] = lmnn2(tr_set, tr_data, tr_label, nknn, 'maxiter', 2500, 'stepsize', 1e-07, 'quiet', 1);

end





