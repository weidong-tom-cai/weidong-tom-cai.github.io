%gen_cluster implements the "reference sub-categorization" module described in our paper:
% Yang Song, Weidong Cai, Heng Huang, Yun Zhou, Dagan Feng, Yue Wang, Michael Fulham, Mei Chen, 
% “Large Margin Local Estimate with Applications to Medical Image Classification”, 
% IEEE Transactions on Medical Imaging, online, 2015.
%
%Input:
%dset -- a data structure containing the feature descriptors of references.
%        Assuming the data has two classes, dset should be structured as follows.
%        dset(1).dict -- is an N by (1+H) matrix, in which each row corresponds to one data instance,
%                        and H is the length of the feature vector. 
%                        For each row, the first element contains
%                        the subject ID and the rest elements contain the feature vector.
%        dset(2).dict -- has the same format as dset(1).dict.
%vp -- a 1 by H vector containing integers of 1 to V (number of views). 
%      Elements belonging to the same view would contain the same integer.
%Output:
%cint -- the assignment of clusters.
%        Assuming the data has two classes, cint is structured as follows.
%        cint(1).ids -- is a 1 by N vector, with each element containing the cluster ID of that data instance.
%        cint(2).ids -- has the same format as cint(1).ids.

function cint = gen_cluster( dset, vp )
%Parameters:
%C1, C2 -- can be hardcoded or tuned as described in paper.
%step -- determines (but not) the number of clusters, 
%        and should be adjusted according to the problem domain.
C1 = 10;
C2 = 10;
step = 20;

dset = comp_ext_dist(dset);
for i=1:size(dset,2)
    dict = dset(i).dict;
    if numel(dict)==0
        continue;
    end
    len = size(dict,2)-1;
    len0 = numel(vp);
    v = max(vp);
    vpx = zeros(1,len);
    vpx(1:len0) = vp;
    vpx(len0+1:len) = v;
    break;
end

for i=1:size(dset,2)
    dm = dset(i).dict;
    if numel(dm)==0
        cint(i).ids = [];
        continue;
    end
    [sx, sy] = size(dm);
    dm = dm(:,2:sy);
    k = ceil(sx/step); % computes the number of clusters
    dim = size(dm,2);
    for j=1:dim
        x = dm(:,j);
        dm(:,j) = x/100;
    end
    [U,Z] = kmeans(dm, k);
    U = U';
    [U,W,V,Z] = twkmeans( dm, k, vpx, C1, C2, Z );
    cint(i).ids = U;
    numk = zeros(1,k);
    for j=1:k
        tmp = (U==j);
        numk(j) = sum(tmp);
    end
    [i,numk]
    cenm(i).cen = Z;
end

end


function out = comp_ext_dist( dset )
%This function computes the feature separation.

nknn = 0.1;

for i=1:size(dset,2)
    dm = dset(i).dict;
    [sx, sy] = size(dm);
    dm = dm(:,2:sy);
    dmx = zeros(sx,size(dset,2)-1);
    cnt = 0;
    for j=1:size(dset,2)
        if i==j
            continue;
        end
        cnt = cnt+1;
        dm2 = dset(j).dict;
        if numel(dm2)==0
            continue;
        end
        num_knn = ceil(nknn*size(dm2,1));
        dm2 = dm2(:,2:sy);
        [idx, dv] = knnsearch(dm2, dm, 'K', num_knn);
        for k=1:sx
            dist = dv(k,:);
            v = mean(dist);
            dmx(k,cnt) = v;
        end
    end
    dset(i).dict = [dset(i).dict, dmx];
end

out = dset;      

end

