%label_cluster implements the "local estimate generation" module described in our paper:
% Yang Song, Weidong Cai, Heng Huang, Yun Zhou, Dagan Feng, Yue Wang, Michael Fulham, Mei Chen, 
% “Large Margin Local Estimate with Applications to Medical Image Classification�?, 
% IEEE Transactions on Medical Imaging, online, 2015.
%
%Input:
%fv -- feature vector of a test data 
%      (or a reference data when this function is invoked from learn_lm.m),
%      for which the local estimates are to be generated.
%cid -- subject ID (scalar) of the data fv.
%dset -- a data structure containing the feature descriptors of references.
%        Assuming the data has two classes, dset should be structured as follows.
%        dset(1).dict -- is an N by (1+H) matrix, in which each row corresponds to one data instance,
%                        and H is the length of the feature vector. 
%                        For each row, the first element contains
%                        the subject ID and the rest elements contain the feature vector.
%        dset(2).dict -- has the same format as dset(1).dict.
%cint -- the assignment of clusters.
%        Assuming the data has two classes, cint is structured as follows.
%        cint(1).ids -- is a 1 by N vector, with each element containing the cluster ID of that data instance.
%        cint(2).ids -- has the same format as cint(1).ids.
%Output:
%rec -- a data structure containing the local estimates and representation errors.

function rec = label_cluster( fv, cid, dset, cint )
%Parameter:
%C -- the sparsity constant
C = 10;

for i=1:size(cint,2)
    ids = cint(i).ids;
    if numel(ids)==0
        rec(i).diff = 0;
        continue;
    end
    numk = max(ids);
    rec(i).diff = zeros(1,numk);
    rec(i).vm = zeros(numk,size(fv,2));
    for k=1:numk
        dict = dset(i).dict;
		cnt = 0;
        for j=1:size(dict,1)
            if ids(j)==k && dict(j,1)~=cid
                cnt = cnt+1;
            end
        end    
        if cnt<=1
            rec(i).diff(k) = 0;
            continue;
        end
        dictx = zeros(cnt,size(dict,2)-1);
        cnt = 0;
        for j=1:size(dict,1)
            if ids(j)==k && dict(j,1)~=cid
                cnt = cnt+1;
                dictx(cnt,:) = dict(j,2:size(dict,2));
            end
        end         
        dict = dictx;
		l = OMP(dict',fv',C);
		v = dict'*l;
		v = v';
		dv = fv-v;
		diff = sum(dv.^2)^0.5;
		rec(i).diff(k) = diff;
		rec(i).vm(k,:) = v;
    end
end

end

