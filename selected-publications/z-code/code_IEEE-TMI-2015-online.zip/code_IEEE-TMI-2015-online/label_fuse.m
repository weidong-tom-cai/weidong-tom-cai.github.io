%label_fuse implements the "large margin aggregation" module described in our paper:
% Yang Song, Weidong Cai, Heng Huang, Yun Zhou, Dagan Feng, Yue Wang, Michael Fulham, Mei Chen, 
% “Large Margin Local Estimate with Applications to Medical Image Classification�?, 
% IEEE Transactions on Medical Imaging, online, 2015.
%
%Input:
%fv -- feature vector of a test data, for which the class label is to be determined.
%cid -- subject ID (scalar) of the data fv.
%dset -- a data structure containing the feature descriptors of references.
%        Assuming the data has two classes, dset should be structured as follows.
%        dset(1).dict -- is an N by (1+H) matrix, in which each row corresponds to one data instance,
%                        and H is the length of the feature vector. 
%                        For each row, the first element contains
%                        the subject ID and the rest elements contain the feature vector.
%        dset(2).dict -- has the same format as dset(1).dict.
%cint -- the assignment of clusters.
%        Assuming the data has two classes, cint is structured as follows.
%        cint(1).ids -- is a 1 by N vector, with each element containing the cluster ID of that data instance.
%        cint(2).ids -- has the same format as cint(1).ids.
%Lm -- a data structure containing the learned transformation matrices.
%      Assuming the data has two classes, Lm should be structured as follows.
%      Lm(1).L -- is an H by H matrix containing the transformation matrix learned for class 1.
%      Lm(2).L -- is an H by H matrix containing the transformation matrix learned for class 2.
%      Refer to learn_lm.m for learning of Lm. 
%Output:
%lb -- class label (scalar) of the test data.

function lb = label_fuse(fv, cid, dset, cint, Lm )
%Parameter:
%num_knn -- the number of top local estimates used (i.e. M in the paper).
num_knn = 3;

rec = label_cluster(fv,cid,dset,cint);
for a=1:size(rec,2) 
	if numel(rec(a).diff)==1 && rec(a).diff==0
		continue;
	end
	for b=1:size(rec(a).diff,2)
		if rec(a).diff(b)==0
			continue;
		end
		v = rec(a).vm(b,:);
		for c=1:size(dset,2)
			L = Lm(c).L;
			dv = (fv-v)*L';
			diff = sum(dv.^2)^0.5;
			rec(a).diff2(b,c) = diff;
		end
	end
end
       
diffset = zeros(1,size(Lm,2));
mind = -1;
for lx=1:size(Lm,2)
    if numel(Lm(lx).L)==0
        tmp = 0;
        for a=1:size(Lm,2)
            tmp = tmp+numel(Lm(a).L);
        end
        if tmp>0
            continue;
        end
    end
    dists = zeros(1,size(rec,2));
    for a=1:size(rec,2)
        ds = rec(a).diff2;
        if numel(ds)==1 && ds==0
            continue;
        end
        dv = ds(:,lx);
        dv = dv(dv>0);
        dv = sort(dv);
        if numel(dv)>num_knn
            dv = dv(1:num_knn);
        end
        v = mean(dv);  
        dists(a) = v;
        %[a,v,dv]                   
    end
    v = dists;
    minld = -1;
    l = -1;
    for a=1:size(rec,2)
        if v(a)==0
            continue;
        end
        if minld==-1 || v(a)<minld
            minld = v(a);
            l = a;
        end                    
    end    
	if mind==-1 || minld<mind
		mind = minld;
		lb = l;
        diffset = v;
	end
end            

end


